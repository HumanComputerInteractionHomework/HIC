CREATE VIEW a AS
  SELECT
    `test`.`record`.`end_location` AS `end_location`,
    `test`.`record`.`u_id`         AS `u_id`,
    count(0)                       AS `num`
  FROM `test`.`record`
  WHERE (hour(`test`.`record`.`end_time`) > 18)
  GROUP BY `test`.`record`.`end_location`, `test`.`record`.`u_id`
  ORDER BY `test`.`record`.`u_id`, `num` DESC;
