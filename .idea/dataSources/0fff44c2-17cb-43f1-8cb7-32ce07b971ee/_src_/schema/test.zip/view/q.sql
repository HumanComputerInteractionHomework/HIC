CREATE VIEW q AS
  (SELECT
     `test`.`deadline`.`id`                            AS `id`,
     date_format(`test`.`commit`.`datetime`, '%Y%m%d') AS `days`,
     count(0)                                          AS `num`
   FROM (`test`.`commit`
     JOIN `test`.`deadline` ON (((`test`.`commit`.`datetime` < `test`.`deadline`.`end_day`) AND
                                 (`test`.`commit`.`datetime` >= `test`.`deadline`.`start_day`))))
   GROUP BY `test`.`deadline`.`id`, `days`);
