CREATE VIEW a1 AS
  SELECT
    `a`.`end_location` AS `end_location`,
    `a`.`u_id`         AS `u_id`,
    `a`.`num`          AS `num`
  FROM `test`.`a`;
