CREATE VIEW article_writer AS
  SELECT
    `test`.`platform_article`.`article_id`                AS `article_id`,
    `test`.`platform_article`.`writer_id`                 AS `writer_id`,
    `test`.`platform_article`.`article_title`             AS `article_title`,
    `test`.`platform_article`.`content`                   AS `content`,
    `test`.`platform_article`.`create_time`               AS `create_time`,
    ifnull(sum(`test`.`platform_deal`.`deal_payment`), 0) AS `ifnull(sum(deal_payment),0)`,
    `test`.`platform_writer`.`writer_name`                AS `writer_name`,
    `test`.`platform_writer`.`writer_email`               AS `writer_email`
  FROM ((`test`.`platform_article`
    LEFT JOIN `test`.`platform_writer`
      ON ((`test`.`platform_writer`.`writer_id` = `test`.`platform_article`.`writer_id`))) LEFT JOIN
    `test`.`platform_deal` ON ((`test`.`platform_deal`.`article_id` = `test`.`platform_article`.`article_id`)))
  GROUP BY `test`.`platform_article`.`article_id`;
