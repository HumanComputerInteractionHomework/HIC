CREATE VIEW mymoney AS
  SELECT
    `test`.`record`.`u_id`       AS `u_id`,
    sum(`test`.`record`.`price`) AS `sum(price)`
  FROM `test`.`record`
  GROUP BY `test`.`record`.`u_id`;
